<?php
$con=new mysqli('localhost','root','','techmeet');
if(!$con){
    die(mysqli_error($con));
}
?>